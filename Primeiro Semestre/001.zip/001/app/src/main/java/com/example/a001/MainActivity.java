package com.example.a001;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText campo, login, senha;
    ArrayList<Usuario>listinha = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) { //Primeiro metodo da activity a ser execultado
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();//Obter o banner com o titulo do app e esconder
        campo = findViewById(R.id.Escreva);//Vincular variavel do java com xnl
        login = findViewById(R.id.login);
        senha = findViewById(R.id.Senha);
        criaUsuario();
    }
    public void clicar(View v){//O view torna visivel ao arquivo xnl
        String Mensagem = "oi,"+campo.getText()+",Galo cego te ama";
        Toast.makeText(this,Mensagem, Toast.LENGTH_SHORT).show();
    }
    public void logar(View v){
        String user = login.getText().toString();
        String pass = senha.getText().toString();
        String mensagem = "Bem vindo!";
        for (Usuario u:listinha){
            if (user.equals(u.getLogin())) && pass.equals(u.getSenha())){
              if (u.isAdmin()){
                  Intent i = new Intent(this,Admin.class);
                  startActivity(i);
              }
              else {
                Intent i = new Intent(this,Comum.class);
                startActivity(i);
            }
              break;
       }
        else {
            mensagem = "Login ou senha incorreta!";
        }
    }
    Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show();

    }

    private void criaUsuario() {
        Usuario u1 = new Usuario(login,"admin",senha "admin", true);
        Usuario u2 = new Usuario(login,"Sakura",senha "Sasa", true);
        Usuario u3 = new Usuario(login,"Manoel",senha "Azul", false);
        Usuario u4 = new Usuario(login,"Ednaldo",senha "Deus", false);
        Usuario u5 = new Usuario(login,"Felipe",senha "De.quatro", false);

        listinha.add(u1);
        listinha.add(u2);
        listinha.add(u3);
        listinha.add(u4);
        listinha.add(u5);
    }

}