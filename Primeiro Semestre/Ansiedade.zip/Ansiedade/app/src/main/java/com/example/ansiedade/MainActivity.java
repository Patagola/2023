package com.example.ansiedade;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.widget.TableLayout;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    TabLayout Tab;
    ViewPager2 pager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        Tab = findViewById(R.id.Tab);
        pager = findViewById(R.id.pager);
        FragmentManager fn = getSupportFragmentManager();
        adaptador adpter = new adaptador(fn,getLifecycle());
        pager.setAdapter(adpter);
        Tab.addTab(Tab.newTab().setText("Primeiro"));
        Tab.addTab(Tab.newTab().setText("Segundo"));
        Tab.addTab(Tab.newTab().setText("Terceiro"));
        Tab.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                pager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                Tab.selectTab(Tab.getTabAt(position));
            }
        });

    }
}
