package com.example.ansiedade;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class adaptador extends FragmentStateAdapter {
    public adaptador(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 1:
        return new Segundo_fra();
            case 2:
        return new Terceiro_fra();
        }
        return new Primeiro_fra();
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
